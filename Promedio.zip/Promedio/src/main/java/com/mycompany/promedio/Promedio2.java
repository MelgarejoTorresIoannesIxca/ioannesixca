
package com.mycompany.promedio;


import java.util.Scanner;
public class Promedio2 {
   private String nombre;
   private String ApellidoPaterno;
   private String ApellidoMatarno;
   private String Grupo;
   private String Carrera;
   private String NombreAsignatura;
   private String NombreAsignatura2;
   private float calificacion;
   private float calificacion2;
   private double promedio;

    public Promedio2() {} //metodo constructor vacio
    
    public Promedio2(String nombre, String ApellidoPaterno, String ApellidoMatarno, String Grupo, String Carrera, String NombreAsignatura,String NombreAsignatura2, float calificacion,float calificacion2, double promedio) {
        this.nombre = nombre;
        this.ApellidoPaterno = ApellidoPaterno;
        this.ApellidoMatarno = ApellidoMatarno;
        this.Grupo = Grupo;
        this.Carrera = Carrera;
        this.NombreAsignatura = NombreAsignatura;
        this.NombreAsignatura2=NombreAsignatura2;
        this.calificacion = calificacion;
        this.calificacion2=calificacion2;
        this.promedio = promedio;
    }

   

    @Override
    public String toString() {
        return "estudiante = " + nombre + " " +  ApellidoPaterno + " " + ApellidoMatarno
                + "\ngrupo= " + Grupo + "\ncarrera= " + Carrera + "\nasignatura            calificacion " + "\n" 
              + NombreAsignatura+ "=" +  "               "  + "  " +  calificacion + "\n"
              + NombreAsignatura2 + "=" + "               "  + "  " + calificacion2  + "\n"
              + "promedio = "  + promedio  ;
    }
    
    

    public String getNombre() {
        return nombre;
    }

    public String getNombreAsignatura2() {
        return NombreAsignatura2;
    }

    public void setNombreAsignatura2(String NombreAsignatura2) {
        this.NombreAsignatura2 = NombreAsignatura2;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getCalificacion2() {
        return calificacion2;
    }

    public void setCalificacion2(float calificacion2) {
        this.calificacion2 = calificacion2;
    }
  
    public String getApellidoPaterno() {
        return ApellidoPaterno;
    }

    public void setApellidoPaterno(String ApellidoPaterno) {
        this.ApellidoPaterno = ApellidoPaterno;
    }

    public String getApellidoMatarno() {
        return ApellidoMatarno;
    }

    public void setApellidoMatarno(String ApellidoMatarno) {
        this.ApellidoMatarno = ApellidoMatarno;
    }

    public String getGrupo() {
        return Grupo;
    }

    public void setGrupo(String Grupo) {
        this.Grupo = Grupo;
    }

    public String getCarrera() {
        return Carrera;
    }

    public void setCarrera(String Carrera) {
        this.Carrera = Carrera;
    }

    public String getNombreAsignatura() {
        return NombreAsignatura;
    }

    public void setNombreAsignatura(String NombreAsignatura) {
        this.NombreAsignatura = NombreAsignatura;
    }

    public float getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(float calificacion) {
        this.calificacion = calificacion;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }
    
}
