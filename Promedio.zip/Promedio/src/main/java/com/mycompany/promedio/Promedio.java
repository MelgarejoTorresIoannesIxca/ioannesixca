    

package com.mycompany.promedio;

import java.util.Scanner;
public class Promedio {

    public static void main(String[] args) {
        hola ();
    }
    public static void hola (){
        Scanner h=new Scanner (System.in);
        Promedio2 i=new Promedio2 ();
        
        
        System.out.println ("nombre :");
        String nombre=h.nextLine();
        i.setNombre(nombre);
        
        System.out.println ("apellido paterno : ");
        String apellidopaterno= h.nextLine();
        i.setApellidoPaterno(apellidopaterno);
        
        System.out.println  ("apellido materno: ");
        String apellidomaterno=h.nextLine();
        i.setApellidoMatarno(apellidomaterno);
        
        System.out.println ("grupo :");
        String grupo=h.nextLine();
        i.setGrupo(grupo);
        
        
        System.out.println ("carrera :");
        String carrera= h.nextLine();
        i.setCarrera(carrera);
        
        System.out.println ("asignatura :");
        String asignatura = h.nextLine();
        i.setNombreAsignatura(asignatura);
        
        System.out.println ("segunda asignatura");
        String asignatura2=h.nextLine();
        i.setNombreAsignatura2(asignatura2);
        
        System.out.println ("calificacion de la primera asignatura :");
        int calificacion = h.nextInt();
        i.setCalificacion(calificacion);
        
        System.out.println("calificacion de la segunda asignatura");
        int calificacion2= h.nextInt();
        i.setCalificacion2(calificacion2);
        
        System.out.println ("----------------------------------------------------");
        double promedio=(calificacion + calificacion2)/2; 
        i.setPromedio(promedio);
        System.out.println (i.toString());
    }
}
